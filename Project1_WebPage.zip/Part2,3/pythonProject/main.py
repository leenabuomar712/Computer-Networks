from datetime import datetime
from socket import *

serverPort = 6500
try:
    serverSocket = socket(AF_INET, SOCK_STREAM) #AF_INET is the address family, and sock stream means oriented connection
    print("Socket created!")
except:
    print("Socket creation failed!")#associate the socket with host name and port number
serverSocket.bind(("", serverPort))
serverSocket.listen(1) #enable the server to accept one connection
while True:
    connection, address = serverSocket.accept()  # getting the client socket object and address
    sentence = connection.recv(1024).decode('utf-8')  # read data sent by the client
    print("The Server Connected With: ", address)
    print("Request: \n", sentence)  # print HTTP request message
    # address contains client ip address and socket number
    clientIp = address[0]  # IP
    clientPort = address[1]  # port number
    URL = sentence.split()[1]  # get request

 #check the request
    if (URL == "/" or URL == "/main.html" or URL == "/index.html"):# html request
        connection.send( "HTTP/1.1 200 OK\r\n".encode())
        print("HTTP/1.1 200 OK\r\n")
        connection.send( "Content-Type: text/html \r\n".encode())
        print("Content-Type: text/html \r\n")
        date = datetime.now()  # to send date & time with the response
        print("Date and Time: " + date.strftime("%d/%m/%Y, %H:%M:%S") + "\r\n")
        connection.send("\r\n".encode()) #carriage return, line feed
        mainfile = open("main.html")
        data = mainfile.read().replace('\n', '')
        connection.send(data.encode())
        mainfile.close()

    elif (URL == "/file.css"):
        connection.send("HTTP/1.1 200 OK\r\n".encode())
        print("HTTP/1.1 200 OK\r\n")
        connection.send("Content-Type: text/css \r\n".encode())
        print("Content-Type: text/html \r\n")
        date = datetime.now()  # to send date & time with the response
        print("Date and Time: " + date.strftime("%d/%m/%Y, %H:%M:%S") + "\r\n")
        connection.send("\r\n".encode())  # carriage return, line feed
        cssfile = open("file.css")
        data = cssfile.read().replace('\n', '')
        connection.send(data.encode())
        cssfile.close()
    #this code for get pictures in interface
    elif (URL == "/icone.png"):
        Image = open("icone.png", "rb")
        connection.send("HTTP/1.1 200 OK\r\n".encode())
        print("HTTP/1.1 200 OK\r\n")
        connection.send("Content-Type: image/png \r\n".encode())
        print("Content-Type: image/png \r\n")
        date = datetime.now()  # to send date & time with the response
        print("Date and Time: " + date.strftime("%d/%m/%Y, %H:%M:%S") + "\r\n")
        connection.send("\r\n".encode())  # carriage return, line feed
        connection.send(Image.read())
    elif (URL == "/male_programmer.png"):
        Image = open("male programmer.png", "rb")
        connection.send("HTTP/1.1 200 OK\r\n".encode())
        print("HTTP/1.1 200 OK\r\n")
        connection.send("Content-Type: image/png \r\n".encode())
        print("Content-Type: image/png \r\n")
        date = datetime.now()  # to send date & time with the response
        print("Date and Time: " + date.strftime("%d/%m/%Y, %H:%M:%S") + "\r\n")
        connection.send("\r\n".encode())  # carriage return, line feed
        connection.send(Image.read())
    elif (URL == "/JP4kG7.jpg"):
        Image = open("JP4kG7.jpg", "rb")
        connection.send("HTTP/1.1 200 OK\r\n".encode())
        print("HTTP/1.1 200 OK\r\n")
        connection.send("Content-Type: image/jpg \r\n".encode())
        print("Content-Type: image/jpg \r\n")
        date = datetime.now()  # to send date & time with the response
        print("Date and Time: " + date.strftime("%d/%m/%Y, %H:%M:%S") + "\r\n")
        connection.send("\r\n".encode())  # carriage return, line feed
        connection.send(Image.read())


    elif (URL == "/imagename.png"):
        pngimg = open("img1.png", "rb")
        connection.send("HTTP/1.1 200 OK\r\n".encode())
        print("HTTP/1.1 200 OK\r\n")
        connection.send("Content-Type: image/png \r\n".encode())
        print("Content-Type: image/png \r\n")
        date = datetime.now()  # to send date & time with the response
        print("Date and Time: " + date.strftime("%d/%m/%Y, %H:%M:%S") + "\r\n")
        connection.send("\r\n".encode())  # carriage return, line feed
        connection.send(pngimg.read())

    elif (URL == "/imagename.jpg"):
        jpgimg = open("img.jpg", "rb")
        connection.send("HTTP/1.1 200 OK\r\n".encode())
        print("HTTP/1.1 200 OK\r\n")
        connection.send("Content-Type: image/png \r\n".encode())
        print("Content-Type: image/png \r\n")
        date = datetime.now()  # to send date & time with the response
        print("Date and Time: " + date.strftime("%d/%m/%Y, %H:%M:%S") + "\r\n")
        connection.send("\r\n".encode())  # carriage return, line feed
        connection.send(jpgimg.read())

    elif ( URL== "/SortByName"):
        sortfile = open("smartphones.txt", "r")
        byname = sortfile.read().splitlines()
        sortfile.close()
        byname.sort() #sort based on names

        connection.send( "HTTP/1.1 200 OK\r\n".encode())
        connection.send(  "Content-Type: text/html; charset=utf-8\r\n".encode())
        connection.send( "\r\n".encode())
        request = "<!DOCTYPE html><html><body><h1><font color=orange>Names and prices of smartphones sorted by Name</font></h1><ol>"
        for i in byname:
            request +=  "<h2><li>" + str(i) + "$" +"</li></h2>"
        request +="</ol></body></html>"
        request += "\r\n"
        connection.sendall(request.encode())

    elif (URL == "/SortByPrice"):
        sortfile = open("smartphones.txt", "r") #open file to red data
        price = sortfile.read().splitlines()
        sortfile.close()
        price.sort(key=lambda x: x.split(':')[1], reverse=True) #descending sort based on price

        connection.send("HTTP/1.1 200 OK\r\n".encode())
        connection.send("Content-Type: text/html; charset=utf-8\r\n".encode())
        connection.send("\r\n".encode())
        request = "<!DOCTYPE html><html><body><h1><font color=magenta>Names and prices of smartphones sorted by Price</font></h1><ol>"
        for i in price:
            request += "<h2><li>" + str(i) + "$" +"</li></h2>"
        request += "</ol></body></html>"
        request += "\r\n"
        connection.sendall(request.encode())

    else:
        #if the request is wrong or the file not found
        connection.send("HTTP/1.1 200 OK\r\n".encode())
        connection.send("Content-Type: text/html; charset=utf-8\r\n".encode())
        connection.send("\r\n".encode())
        connection.send(("<!DOCTYPE html><html><title>ERROR</title><center><h1> HTTP/1.1 404 Not Found</h1></center>"
                          +"<h2><center><font color=black>Error" +" <h2><center><font color=Red> The File Is Not Found</font></center></h2>"
         +"<h3><center><b>Leen Abu Omar - 1190113 | Jihad Rashada - 1190777</b></center></h3>"
         +"<h3><center>IP And Port Number Of The Client:"+str(clientIp)+", "+str(clientPort)+"</center></h3></html>") .encode())

    connection.close()
    print("Connection:close")
